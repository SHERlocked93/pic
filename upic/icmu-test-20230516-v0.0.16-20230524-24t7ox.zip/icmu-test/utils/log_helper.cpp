/*
创建于 2023年2月20日
创建: QianYu
功能: Log 处理
*/

#include "log_helper.h"

LogHelper::LogHelper(QObject* parent)
    : QObject{parent} {}

// 保存到
void LogHelper::saveLogFile(QString logData, QString logSuffix, QString logDirPath)
{
    QString logPath = QDir::currentPath() + logDirPath;
    QDir dir;
    if (!dir.exists(logPath)) {
        bool res = dir.mkpath(logPath);
        if (res != true) {
            QMessageBox::critical(qobject_cast<QWidget*>(parent()), "Error", " 文件夹创建失败。");
            return;
        }
    }
    dir.setPath(logPath);

    QString strNow = QDateTime::currentDateTime().toString("yyyy_MM_dd_hh_mm_ss_zzz");
    QString filePath = dir.filePath(strNow + logSuffix);
    qDebug() << "文档路径: " << dir.currentPath() << filePath << endl;
    QFile file(filePath);
    if (!file.open(QIODevice::ReadWrite | QIODevice::Text)) {
        QMessageBox::critical(qobject_cast<QWidget*>(parent()), "Error", "无法保存文件");
    }
    file.write(logData.toUtf8());
    file.close();
    qDebug() << QString(" 文件夹创建成功。地址：") + QFileInfo(file).absoluteFilePath() << endl;
}

// 打开txt文件
QString LogHelper::openTxtFile()
{
    QString fileName = QFileDialog::getOpenFileName(qobject_cast<QWidget*>(parent()), "打开TXT文件", QString(), "Text Files (*.txt)");
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::critical(qobject_cast<QWidget*>(parent()), "Error", "无法打开文件");
        }
        QTextStream in(&file);
        QString fileContent = in.readAll();
        file.close();
        if (fileContent.size() > 225) {
            QMessageBox::critical(qobject_cast<QWidget*>(parent()), "Error", "TXT文件文本长度长于 225 byte");
        }
        return fileContent;
    }
    return "";
}
