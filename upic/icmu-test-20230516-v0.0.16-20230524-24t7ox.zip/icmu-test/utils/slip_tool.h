#ifndef SLIP_TOOL_H
#define SLIP_TOOL_H

#include <QByteArray>
#include <QDebug>
#include <QObject>

static const uchar SLIP_END = 0xC0; // END (0xc0)
static const uchar SLIP_ESC = 0xDB; // ESC (0xdb)
static const uchar SLIP_DC = 0xDC;  // 如果IP数据报中有END字符，则需要用ESC字符加0xdc替代
static const uchar SLIP_DD = 0xDD;  // 如果IP数据报中有ESC字符，则需要用ESC加0xdd替代

class SlipTool : public QObject {
    Q_OBJECT

public:
    explicit SlipTool(QObject* parent = nullptr);

    QByteArray encode(const QByteArray& data);
    QByteArray decode(const QByteArray& data);
    static int tryLoad(QByteArray& cache, QByteArray& data);
};

#endif // SLIP_TOOL_H
