/*
 * @Author: Gu Wei
 * @Date: 2021-07-23 22:12:33
 * @LastEditors: Gu Wei
 * @LastEditTime: 2021-08-02 09:55:10
 * @Description:
 */

#ifndef _CRC16_CCITT_h
#define _CRC16_CCITT_h

#undef FALSE
#undef TRUE
#define FALSE 0
#define TRUE  !FALSE

typedef unsigned short crc;

#define CRC_NAME          "CRC16-CCITT"
#define POLYNOMIAL        0x1021
#define INITIAL_REMAINDER 0x0000
#define FINAL_XOR_VALUE   0x0000
#define REFLECT_DATA      TRUE
#define REFLECT_REMAINDER TRUE

#ifdef __cplusplus
extern "C" {
#endif

void crcInit();
crc crc_ccitt_16calc(unsigned char const message[], int nBytes);
crc ACrc16(const unsigned char* buf, crc len);

#ifdef __cplusplus
}
#endif

#endif //_CRC16_CCITT_h
