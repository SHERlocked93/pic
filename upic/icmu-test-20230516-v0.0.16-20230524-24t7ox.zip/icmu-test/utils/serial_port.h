#ifndef SERIALPORT_H
#define SERIALPORT_H

#include <QDateTime>
#include <QMutex>
#include <QObject>
#include <QtSerialPort/QSerialPort>

#include "utils/slip_tool.h"

class SerialPort : public QObject {
    Q_OBJECT

public:
    SerialPort(QObject* parent = nullptr);
    ~SerialPort();

    int openPort(QString portName,
                 int baudRate,
                 QSerialPort::DataBits dataBits = QSerialPort::Data8,
                 QSerialPort::Parity parity = QSerialPort::NoParity,
                 QSerialPort::StopBits stopBits = QSerialPort::OneStop);
    void closePort();
    bool isOpened();

    void writeData(QByteArray data);
signals:
    void newDataReceived(QByteArray data);
    void portError(QString errorString);
    bool openStatusChange(bool, QString = "");

private slots:
    void handleError(QSerialPort::SerialPortError error);
    void readDataFromPort();

private:
    QSerialPort* m_serialPort;
    QByteArray cache_;
    //    QDateTime startTime;
};

#endif // SERIALPORT_H
