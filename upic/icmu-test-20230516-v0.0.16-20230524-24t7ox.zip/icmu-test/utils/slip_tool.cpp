/*
创建于 2023年2月20日
创建: QianYu
功能: SLIP 转译
*/

#include "utils/slip_tool.h"

SlipTool::SlipTool(QObject* parent)
    : QObject(parent) {}

// 将通讯内容转化为SLIP协议
QByteArray SlipTool::encode(const QByteArray& byteArrData)
{
    QByteArray encodedData;
    encodedData.reserve(byteArrData.size() * 2);

    // SLIP 报文开头为 END
    encodedData.append(SLIP_END);

    // 将原始数据中的特殊字符转义并加入到 encodedData 中
    for (int i = 1; i < byteArrData.size() - 1; ++i) {
        const auto& byteItem = byteArrData[i];
        switch (static_cast<uchar>(byteItem)) {
        case SLIP_END: // 如果遇到 END 字符，则转义为 ESC 0xDC
            encodedData.append(SLIP_ESC);
            encodedData.append(SLIP_DC);
            break;
        case SLIP_ESC: // 如果遇到 ESC 字符，则转义为 ESC 0xDD
            encodedData.append(SLIP_ESC);
            encodedData.append(SLIP_DD);
            break;
        default:
            encodedData.append(byteItem);
            break;
        }
    }

    // SLIP 报文结尾为 END
    encodedData.append(SLIP_END);
    return encodedData;
}

// 将接收到的SLIP协议解码为通讯内容，解码的内容不包括头尾0xC0
QByteArray SlipTool::decode(const QByteArray& byteArrData)
{
    QByteArray decodedData;

    if (!byteArrData.startsWith(SLIP_END) ||
        !byteArrData.endsWith(SLIP_END)) {
        throw QString("in SlipTool::decode  SLIP头尾格式错误");
        qDebug() << "in SlipTool::decode  SLIP头尾格式错误";
    }

    for (int i = 1; i < byteArrData.size() - 1; ++i) {
        if (static_cast<uchar>(byteArrData.at(i)) == SLIP_ESC) {
            ++i;
            if (static_cast<uchar>(byteArrData.at(i)) == SLIP_DC) {
                decodedData.append(SLIP_END);
            } else if (static_cast<uchar>(byteArrData.at(i)) == SLIP_DD) {
                decodedData.append(SLIP_ESC);
            } else {
                throw QString("in SlipTool::decode  SLIP格式错误");
                qDebug() << "in SlipTool::decode  SLIP格式错误"
                         << "ESC 后的字符既不是 0xDC 也不是 0xDD，说明数据有误，应该进行错误处理" << endl;
            }
        } else {
            decodedData.append(byteArrData.at(i));
        }
    }
    return decodedData;
}

// SLIP解析前 c0 00 05 db dc db dd 11 db dd db dc 22 fc d2 c0 后可能还有其他数据
// SLIP解析后 c0 00 05 c0 db 11 db c0 22 fc d2 c0
// 从data中获取合法数据，后面可能还跟着其他帧的部分数据
int SlipTool::tryLoad(QByteArray& cache, QByteArray& data)
{
    if (!cache.startsWith(SLIP_END)) {
        qDebug() << "in SlipTool::tryLoad  warning: 接受到非 SLIP_END c0 头";
    }
    int start = cache.indexOf(SLIP_END);
    int end = cache.indexOf(SLIP_END, start + 1);

    if (start == -1 || end == -1) {
        return EXIT_FAILURE;
    }

    // 获取第一个c0第二个c0及其之间数据
    data = cache.mid(start, end - start + 1);
    cache.remove(0, end + 1);
    return EXIT_SUCCESS;
}
