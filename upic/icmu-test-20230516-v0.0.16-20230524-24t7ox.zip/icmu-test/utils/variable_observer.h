/*
创建于 2023年2月20日
创建: QianYu
功能: 数值变化触发回调
*/

#ifndef MYOBSERVER_H
#define MYOBSERVER_H

#include <QDebug>
#include <functional>

using namespace std;

template <typename T>
class MyObserver {
public:
    MyObserver() {}
    virtual ~MyObserver() {}

public:
    T getValue() const
    {
        return m_value;
    }

    void setValue(const T& newValue)
    {
        if (m_value != newValue) {
            m_value = newValue;
            emitValueChanged(newValue);
        }
    }

    void setValueChangeCallback(const function<void(T)>& callback)
    {
        m_callback = callback;
    }

    T operator=(const T& initVal)
    {
        setValue(initVal);
        return m_value;
    }

protected:
    virtual void emitValueChanged(const T& newValue)
    {
        if (m_callback) {
            m_callback(newValue);
        }
    }

private:
    T m_value;
    function<void(T)> m_callback;
};

#endif // MYOBSERVER_H
