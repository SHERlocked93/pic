/*
创建于 2023年2月20日
创建: QianYu
功能: 串口通信
*/

#include "utils/serial_port.h"

SerialPort::SerialPort(QObject* parent)
    : QObject(parent)
{
    m_serialPort = new QSerialPort(this);

    connect(m_serialPort, &QSerialPort::errorOccurred, this, &SerialPort::handleError);
    connect(m_serialPort, &QSerialPort::readyRead, this, &SerialPort::readDataFromPort);
}

SerialPort::~SerialPort()
{
    emit openStatusChange(m_serialPort->isOpen());
    closePort();
}

int SerialPort::openPort(QString portName, int baudRate, QSerialPort::DataBits dataBits, QSerialPort::Parity parity, QSerialPort::StopBits stopBits)
{
    m_serialPort->setPortName(portName);
    m_serialPort->setBaudRate(baudRate);
    m_serialPort->setDataBits(dataBits);
    m_serialPort->setParity(parity);
    m_serialPort->setStopBits(stopBits);

    if (m_serialPort->open(QIODevice::ReadWrite)) {
        m_serialPort->setDataTerminalReady(true); // 设置DTR控制线为高电平，1起始位
        emit openStatusChange(m_serialPort->isOpen(), portName);
        return EXIT_SUCCESS;
    } else {
        emit portError(m_serialPort->errorString());
        emit openStatusChange(m_serialPort->isOpen());
        return EXIT_FAILURE;
    }
}

void SerialPort::closePort()
{
    if (m_serialPort->isOpen()) {
        m_serialPort->close();
        emit openStatusChange(m_serialPort->isOpen());
    }
}

bool SerialPort::isOpened()
{
    return m_serialPort->isOpen();
}

void SerialPort::writeData(QByteArray data)
{
    m_serialPort->write(data);
}

void SerialPort::handleError(QSerialPort::SerialPortError error)
{
    if (error != QSerialPort::NoError) {
        emit portError(m_serialPort->errorString());
    }
}

void SerialPort::readDataFromPort()
{
    QDateTime startTime = QDateTime::currentDateTime();

    if (startTime.msecsTo(QDateTime::currentDateTime()) <= 500) {
        cache_.append(m_serialPort->readAll());
    }

    while (cache_.length()) {
        QByteArray data;
        int ret = SlipTool::tryLoad(cache_, data);
        if (ret != EXIT_SUCCESS) {
            qDebug() << " Error 解析出错：" << cache_.toHex(' ');
            break;
        } else {
            emit newDataReceived(data);
        }
    }

    //    while (m_serialPort->waitForReadyRead(500)) {  // 同时多个数据过来时卡死
    //        cache_.append(m_serialPort->readAll());
    //    }
}
