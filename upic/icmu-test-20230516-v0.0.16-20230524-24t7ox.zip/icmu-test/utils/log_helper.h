#ifndef LOGHELPER_H
#define LOGHELPER_H

#include <QDebug>
#include <QDir>
#include <QFileDialog>
#include <QMessageBox>
#include <QObject>
#include <QTime>

class LogHelper : public QObject {
    Q_OBJECT
public:
    explicit LogHelper(QObject* parent = nullptr);

    void saveLogFile(QString logData, QString logSuffix, QString logDirPath);
    QString openTxtFile();
};

#endif // LOGHELPER_H
