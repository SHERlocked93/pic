#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <Dialogs/comparewindow.h>

#include <QDateTime>
#include <QDebug>
#include <QFileDialog>
#include <QMainWindow>
#include <QMap>
#include <QMessageBox>
#include <QTextCodec>
#include <QTextStream>
#include <QTimer>
#include <QtAlgorithms>
#include <QtMath>

#include "Dialogs/opendialog.h"
#include "utils/crc_ccitt_16.h"
#include "utils/log_helper.h"
#include "utils/slip_tool.h"
#include "utils/variable_observer.h"

#define MSG_PRIORITY_HIGH   "1" // 优先级 1  （最高）
#define MSG_PRIORITY_NORMAL "2" // 优先级 2
#define MSG_PRIORITY_LOW    "3" // 优先级 3

#define MSG_TYPE_APP_DATA    "1" // 消息类型：应用数据帧
#define MSG_TYPE_ACK         "2" // 消息类型：ACK/NACK帧
#define MSG_TYPE_LINK_STATUS "3" // 消息类型：链路状态帧
#define MSG_TYPE_SILENT      "4" // 消息类型：静默控制/状态
#define MSG_TYPE_LAST_MSG    "5" // 消息类型：静默控制/状态

#define HF_HEARTBEAT_INTERVAL 2000 // HF心跳周期 项目要求5000

#define MSG_RESEND_NUM      3   // 消息重发次数 项目要求3
#define MSG_RESEND_INTERVAL 500 // 消息重发间隔 项目要求500

#define HF_SILENT     0x01 // hf静默
#define HF_NOT_SILENT 0x00 // hf非静默

#define PATH_LOG       "/Log"                 // log 文件路径
#define PATH_SEND_DATA "/AllMessage/SendData" // SendData 路径
#define PATH_RECV_DATA "/AllMessage/RecvData" // RecvData 路径

using std::string;

QT_BEGIN_NAMESPACE
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE

const QMap<QString, uchar> LinkTypeMap = {
    {"空军短波", 0x00},
    {"全军短波", 0x01}}; // 信道链路类型
const QMap<QString, uchar> LinkStatusMap = {
    {"未入网/未建链", 0x00},
    {"已入网/已建链", 0x01}}; // 信道建链/入网状态
const QMap<QString, uchar> NetStatusMap = {
    {"成员入网成功", 0x00},
    {"成员入网未知", 0x01}}; // 成员入网状态
const QMap<QString, uchar> SilentMap = {
    {"非静默", 0x00},
    {"静默", 0x01}}; // 无线电静默状态
const QMap<QString, uchar> DatalinkRateMap = {
    {"未知", 0x00},
    {"600bps", 0x01},
    {"880bps", 0x02},
    {"1600bps", 0x03},
    {"2320bps", 0x04},
    {"3040bps", 0x05}}; // 短波数据链速率
const QMap<QString, uchar> FaultStatusMap = {
    {"正常", 0x00},
    {"故障", 0x01}}; // 电台故障状态
const QMap<QString, uchar> MsgPrioMap = {
    {MSG_PRIORITY_HIGH, 0x01},
    {MSG_PRIORITY_NORMAL, 0x02},
    {MSG_PRIORITY_LOW, 0x03}}; // 优先级
const QMap<string, uchar> MsgTypeMap = {
    {MSG_TYPE_APP_DATA, 0x01 << 2},
    {MSG_TYPE_ACK, 0x02 << 2},
    {MSG_TYPE_LINK_STATUS, 0x03 << 2},
    {MSG_TYPE_SILENT, 0x04 << 2},
    {MSG_TYPE_LAST_MSG, 0x05 << 2}}; // 消息类型

class MainWindow : public QMainWindow {
    Q_OBJECT

    QTimer* hfHeartbeatTimer; // hf心跳
    QTimer* icmuResendTimer;  // icmu消息确认
    QTimer* hfResendTimer;    // hf消息确认

    int icmuResendCount; // icmu当前消息重发次数，到 MSG_RESEND_NUM 后发送失败并丢弃
    int hfResendCount;   // hf当前消息重发次数，到 MSG_RESEND_NUM 后发送失败并丢弃

public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();
    SlipTool m_slipTool;
    LogHelper m_logHelper;

    void msgCheck(QByteArray byteArrData);

private:
    OpenDialog* m_OpenDialog;       // icmu设置串口连接数据
    OpenDialog* m_OpenDialog2;      // hf设置串口连接数据
    CompareWindow* m_CompareWindow; // 数据比对

    MyObserver<bool> icmu_hfIsConnected;   // icmu认知的，电台成员入网
    MyObserver<bool> icmu_hfIsSilent;      // icmu认知的，电台静默状态
    MyObserver<bool> icmu_hfNotVoiceFirst; // icmu认知的，电台话音优先无效
    MyObserver<bool> icmuReceiveAckFlag;   // icmu发消息后是否接收到对方回复的ack
    MyObserver<bool> hfReceiveAckFlag;     // hf发消息后是否接收到对方回复的ack
    MyObserver<bool> hfIsSilent;           // hf是否静默

    bool showHeartbeat; // icmu log 显示心跳

    QString openTxtFile();
    QByteArray msgFormat(QByteArray, uchar);

private:
    QByteArray icmu_msgFormat(QByteArray);

    void icmuResend(QByteArray);
    void icmuReceive(QByteArray);

    QByteArray data_icmu2hf_data(string);
    QByteArray data_icmu2hf_ack();
    QByteArray data_icmu2hf_silent(uchar);
    QByteArray data_icmu2hf_lastMsg(uchar);

private:
    QByteArray hf_msgFormat(QByteArray);
    void hfResend(QByteArray);
    void hfReceive(QByteArray);

    QByteArray hf_geneHeartbeat();

    QByteArray data_hf2icmu_data(string);
    QByteArray data_hf2icmu_ack();
    QByteArray data_hf2icmu_state();
    QByteArray data_hf2icmu_silent(uchar);

private slots:
    void on_btnIcmuDataSend_clicked();

    void on_btnPortOpen_clicked();

    void on_btnPortClose_clicked();

    void on_comboLinkType_currentTextChanged(const QString& arg1);

    void on_btnIcmuDataLoad_clicked();

    void on_btnHfDataLoad_clicked();

    void on_btnHfDataSend_clicked();

    void on_btnIcmuSilent_clicked();

    void on_btnIcmuNotSilent_clicked();

    void on_btnHfSilent_clicked();

    void on_btnHfNoSilent_clicked();

    void on_btnIcmuLogExport_clicked();

    void on_btnHfLogExport_clicked();

    void on_btnDataCompare_clicked();

    void on_btnPortOpen2_clicked();

    void on_btnPortClose2_clicked();

    void on_checkBoxShowHeartbeat_stateChanged(int arg1);

    void on_btnIcmuSendLastMsg_clicked();

private:
    Ui::MainWindow* ui;
};
#endif // MAINWINDOW_H
