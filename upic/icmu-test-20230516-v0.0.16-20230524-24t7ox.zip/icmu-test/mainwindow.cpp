#include "mainwindow.h"

#include "Dialogs/comparewindow.h"
#include "Dialogs/opendialog.h"
#include "ui_mainwindow.h"

using std::string;

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , m_slipTool(this)
    , m_logHelper(this)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    crcInit();
    setWindowTitle(tr("ICMU/HF 测试工具 0.0.16"));
    m_CompareWindow = new CompareWindow();

    m_OpenDialog = new OpenDialog();
    m_OpenDialog2 = new OpenDialog();

    connect(m_OpenDialog->m_serialPort, &SerialPort::openStatusChange, [&](bool isOpen, QString portName) {
        ui->labelPortStatus->setText(isOpen ? ("<span style='color: green'>" + portName + " 已打开</span>") : "<span style='color: red'>关闭</span>");
    });

    connect(m_OpenDialog->m_serialPort, &SerialPort::newDataReceived, this, &MainWindow::icmuReceive);

    connect(m_OpenDialog2->m_serialPort, &SerialPort::openStatusChange, [&](bool isOpen, QString portName) {
        ui->labelPortStatus2->setText(isOpen ? ("<span style='color: green'>" + portName + " 已打开</span>") : "<span style='color: red'>关闭</span>");
    });

    connect(m_OpenDialog2->m_serialPort, &SerialPort::newDataReceived, this, &MainWindow::hfReceive);

    showHeartbeat = true;
    icmu_hfIsConnected = false;
    icmu_hfNotVoiceFirst = false;
    icmu_hfIsSilent = false;

    icmu_hfIsConnected.setValueChangeCallback([&](bool isConnected) {
        ui->btnIcmuDataSend->setEnabled(isConnected && icmu_hfNotVoiceFirst.getValue() && !icmu_hfIsSilent.getValue());
        ui->labelIcmuHfNetStatus->setText(isConnected ? "<span style='color: green'>成员入网成功</span>" : "<span style='color: red'>成员入网未知</span>");
    });

    icmu_hfNotVoiceFirst.setValueChangeCallback([&](bool isNotVoiceFirst) {
        ui->btnIcmuDataSend->setEnabled(icmu_hfIsConnected.getValue() && isNotVoiceFirst && !icmu_hfIsSilent.getValue());
        ui->labelIcmuHfVoiceFirst->setText(isNotVoiceFirst ? "<span style='color: green'>无效</span>" : "<span style='color: red'>有效</span>");
    });

    icmu_hfIsSilent.setValueChangeCallback([&](bool isSilent) {
        ui->btnIcmuDataSend->setEnabled(icmu_hfIsConnected.getValue() && icmu_hfIsSilent.getValue() && !isSilent);
        ui->labelIcmuHfSilent->setText(isSilent ? "<span style='color: grey'>静默</span>" : "<span style='color: green'>非静默</span>");
    });

    hfIsSilent = false; // hf默认非静默
    hfIsSilent.setValueChangeCallback([&](bool isSilent) {
        ui->labelHfSilent->setText(isSilent ? "<span style='color: grey'>静默</span>" : "<span style='color: green'>非静默</span>");
    });

    icmuReceiveAckFlag = false;
    hfReceiveAckFlag = false;
    icmuResendCount = 0;
    hfResendCount = 0;
    icmuResendTimer = new QTimer();
    hfResendTimer = new QTimer();
    hfHeartbeatTimer = new QTimer();

    // icmu接到ack消息
    icmuReceiveAckFlag.setValueChangeCallback([&](bool receiveAck) {
        qDebug() << "icmuReceiveAckFlag ValueChangeCallback: " << receiveAck << endl;
        if (!receiveAck) return;
        icmuResendCount = 0;
        icmuResendTimer->stop();
        disconnect(icmuResendTimer, &QTimer::timeout, nullptr, nullptr);
        icmuReceiveAckFlag = false;
    });

    // hf接到ack消息
    hfReceiveAckFlag.setValueChangeCallback([&](bool receiveAck) {
        qDebug() << "hfReceiveAckFlag ValueChangeCallback: " << receiveAck << endl;
        if (!receiveAck) return;
        hfResendCount = 0;
        hfResendTimer->stop();
        disconnect(hfResendTimer, &QTimer::timeout, nullptr, nullptr);
        hfReceiveAckFlag = false;
    });

    connect(hfHeartbeatTimer, &QTimer::timeout, [&]() {
        if (!hfIsSilent.getValue()) m_OpenDialog2->m_serialPort->writeData(m_slipTool.encode(hf_geneHeartbeat()));
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 打开串口
void MainWindow::on_btnPortOpen_clicked()
{
    m_OpenDialog->exec();
}

// 打开串口2
void MainWindow::on_btnPortOpen2_clicked()
{
    hfHeartbeatTimer->start(HF_HEARTBEAT_INTERVAL); // 短波电台上电后周期5s上报“HF/ICMU-3链路状态帧”
    m_OpenDialog2->exec();
}

// 关闭串口
void MainWindow::on_btnPortClose_clicked()
{
    icmu_hfIsConnected = false; // todo:更新状态位置
    icmu_hfNotVoiceFirst = false;
    m_OpenDialog->closePort();
    ui->labelIcmuHfLinkType->setText("空军短波");
    ui->labelIcmuHfLinkStatus->setText("未入网/未建链");
    ui->labelIcmuHfDatalinkRate->setText("未知");
    ui->labelIcmuHfFaultStatus->setText("正常");
}

// 关闭串口2
void MainWindow::on_btnPortClose2_clicked()
{
    hfHeartbeatTimer->stop();
    m_OpenDialog2->closePort();
}

// 带重发的发送
void MainWindow::icmuResend(QByteArray sendData)
{
    auto sendMsg = [=]() {
        icmuResendCount++;
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:blue'> ICMU发送 icmuResend SLIP转义后: </b>第" + QString::fromStdString(to_string(icmuResendCount)) + "次");
        if (hfResendCount == 0) ui->textIcmuLog->append(sendData.toHex(' '));
        m_OpenDialog->m_serialPort->writeData(m_slipTool.encode(sendData));
        qDebug() << "icmuResend: " << sendData.toHex(' ') << endl;
    };

    connect(icmuResendTimer, &QTimer::timeout, [=]() {
        qDebug() << " in icmuResend connect " << icmuResendCount << endl;
        if (icmuResendCount >= MSG_RESEND_NUM) { // 超时
            icmuResendCount = 0;
            icmuResendTimer->stop();
            disconnect(icmuResendTimer, &QTimer::timeout, nullptr, nullptr);
            qDebug() << "icmuResend 未收到ack 消息丢弃: " << sendData.toHex(' ') << endl;
            ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'> icmuResend 未收到ack消息丢弃: </b><br>" + sendData.toHex(' '));
        } else {
            qDebug() << " in icmuResend connect send " << icmuResendCount << endl;
            sendMsg();
        }
    });
    sendMsg();
    icmuResendTimer->start(MSG_RESEND_INTERVAL);
}

void MainWindow::icmuReceive(QByteArray receive)
{
    QByteArray byteArrData;

    try {
        byteArrData = m_slipTool.decode(receive); // 不包括头尾0xCO
        qDebug() << "icmuReceive 接受信息 转义前: " << receive.toHex(' ') << endl
                 << "转义后: " << byteArrData.toHex(' ') << endl;

        msgCheck(byteArrData);
    } catch (const QString& errorMsg) {
        qCritical() << "Error occurred: " << errorMsg << receive.toHex(' ') << endl;
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'>ICMU接收 SLIP转义出错: </b><br>" + receive.toHex(' '));
    }

    uchar msgType = byteArrData[2] >> 2 << 2;
    if (msgType == MsgTypeMap[MSG_TYPE_APP_DATA]) {
        m_logHelper.saveLogFile(QString(byteArrData.mid(3, byteArrData.length() - 3 - 4)), "_test.dat", PATH_RECV_DATA);
        qDebug() << "in MSG_TYPE_APP_DATA icmu接收数据帧 " << byteArrData.toHex(' ');
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>ICMU接收 数据帧: </b><br>" + byteArrData.toHex(' '));
        m_OpenDialog->m_serialPort->writeData(m_slipTool.encode(icmu_msgFormat(data_icmu2hf_ack())));
    } else if (msgType == MsgTypeMap[MSG_TYPE_ACK]) {
        qDebug() << "in MSG_TYPE_ACK icmu接收ack " << byteArrData.toHex(' ');
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>ICMU接收 ACK: </b><br>" + byteArrData.toHex(' '));
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:blue'>ICMU消息发送成功 </b>");
        icmuReceiveAckFlag = true;
    } else if (msgType == MsgTypeMap[MSG_TYPE_LINK_STATUS]) {
        qDebug() << "in MSG_TYPE_LINK_STATUS icmu接收链路状态帧 " << byteArrData.toHex(' ');
        if (showHeartbeat)
            ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>ICMU接收 链路状态帧: </b><br>" + byteArrData.toHex(' '));
        QByteArray linkStatusData = byteArrData.mid(3, 6);

        auto findKey = [&](const QMap<QString, uchar> map, uchar val) {
            //        auto item = qFind(map.begin(), map.end(), [&](QPair<QString, uchar>& p) { return p.second == val; });  // qt莫名其妙报错
            for (auto it = map.cbegin(); it != map.cend(); ++it) {
                if (it.value() == val) {
                    return it.key();
                }
            }
            return QString("<span style='color: red'>ERROR：非法数据</span>");
        };

        ui->labelIcmuHfLinkType->setText(findKey(LinkTypeMap, linkStatusData[0]));
        ui->labelIcmuHfLinkStatus->setText(findKey(LinkStatusMap, linkStatusData[1]));
        icmu_hfIsConnected = !linkStatusData[2];
        icmu_hfNotVoiceFirst = !linkStatusData[3];
        ui->labelIcmuHfDatalinkRate->setText(findKey(DatalinkRateMap, linkStatusData[4]));
        ui->labelIcmuHfFaultStatus->setText(findKey(FaultStatusMap, linkStatusData[5]));

    } else if (msgType == MsgTypeMap[MSG_TYPE_SILENT]) {
        qDebug() << "in MSG_TYPE_LINK_STATUS icmu接收静默 " << byteArrData.toHex(' ');
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>ICMU接收 静默:  </b><br>" + byteArrData.toHex(' '));
        QByteArray silentData = byteArrData.mid(3, 1);
        icmu_hfIsSilent = silentData[0];
        m_OpenDialog->m_serialPort->writeData(m_slipTool.encode(icmu_msgFormat(data_icmu2hf_ack())));
    } else if (msgType == MsgTypeMap[MSG_TYPE_LAST_MSG]) {
        qDebug() << "in MSG_TYPE_LAST_MSG icmu接收历史链路数据内容 " << byteArrData.toHex(' ');
        icmuReceiveAckFlag = true;
        QString lastMsgSufficLog = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        ui->textIcmuLog->append(lastMsgSufficLog + " <b style='color:green'>ICMU接收 历史链路数据:  </b><br>" + byteArrData.toHex(' '));

        auto lastMsgData = byteArrData.mid(3, byteArrData.size() - 3 - 2);
        int cirNum = lastMsgData[0]; // 循环体数量
        ui->textIcmuLog->append("->循环体数量:" + QString::number(cirNum));

        lastMsgData = lastMsgData.mid(1);
        ui->textIcmuLog->append("->" + lastMsgData.toHex(' '));
        for (int i = 0; i < cirNum; i++) {
            int seq = lastMsgData[0];
            int direct = lastMsgData[1];
            QByteArray timeStampArr = lastMsgData.mid(2, 4);
            quint32 timeStamp = (static_cast<quint32>(timeStampArr[3]) << 24) +
                                (static_cast<quint32>(timeStampArr[2]) << 16) +
                                (static_cast<quint32>(timeStampArr[1]) << 8) +
                                static_cast<quint32>(timeStampArr[0]);
            QDateTime dateTime = QDateTime::fromSecsSinceEpoch(timeStamp).toUTC();
            qDebug() << "time : " << timeStampArr.toHex(' ') << " ---- " << timeStamp;
            ui->textIcmuLog->append("->当前序号:" + QString::number(seq) + " 方向:" + QString::number(direct) + " 时间:" + dateTime.toString("yyyy_MM_dd_hh_mm_ss_zzz"));
            int dataLength = lastMsgData[6];
            auto data = lastMsgData.mid(7, dataLength);

            QTextCodec* codec = QTextCodec::codecForName("UTF-8");
            QString str = codec->toUnicode(data);
            ui->textIcmuLog->append("->数据:" + str);
            lastMsgData = lastMsgData.mid(7 + dataLength);
        }
    } else {
        qCritical() << "Error： 本消息不属于任何消息类型 in void MainWindow::icmuReceive" << endl;
        ui->textIcmuLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'>ICMU接收 不属于任何消息类型: </b><br>" + byteArrData.toHex(' '));
    }
}

// 带重发的发送
void MainWindow::hfResend(QByteArray sendData)
{
    auto sendMsg = [=]() {
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:blue'> HF发送 hfResend SLIP转义后: </b>第" + QString::fromStdString(to_string(hfResendCount)) + "次");
        if (hfResendCount == 0) ui->textHfLog->append(sendData.toHex(' '));
        hfResendCount++;
        m_OpenDialog2->m_serialPort->writeData(m_slipTool.encode(sendData));
        qDebug() << "hfResend: " << sendData.toHex(' ') << endl;
    };

    connect(hfResendTimer, &QTimer::timeout, [=]() {
        qDebug() << " in hfResend connect " << hfResendCount << endl;
        if (hfResendCount >= MSG_RESEND_NUM) { // 超时
            hfResendCount = 0;
            hfResendTimer->stop();
            disconnect(hfResendTimer, &QTimer::timeout, nullptr, nullptr);
            qDebug() << "hfResend 未收到ack 消息丢弃: " << sendData.toHex(' ') << endl;
            ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'> hfResend 未收到ack消息丢弃: </b><br>" + sendData.toHex(' '));
        } else {
            qDebug() << " in hfResend connect send " << hfResendCount << endl;
            sendMsg();
        }
    });
    sendMsg();
    hfResendTimer->start(MSG_RESEND_INTERVAL);
}

void MainWindow::hfReceive(QByteArray receive)
{
    QByteArray byteArrData;

    try {
        byteArrData = m_slipTool.decode(receive);
        qDebug() << "hfReceive 接受信息 转义前: " << receive.toHex(' ') << endl
                 << "转义后: " << byteArrData.toHex(' ') << endl;

        msgCheck(byteArrData);
    } catch (const QString& errorMsg) {
        qDebug() << "Error occurred: " << errorMsg << receive.toHex(' ') << endl;
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'>ICMU接收 SLIP转义出错: </b><br>" + receive.toHex(' '));
    }

    uchar msgType = (byteArrData[2] >> 2) << 2;
    if (msgType == MsgTypeMap[MSG_TYPE_APP_DATA]) {
        qDebug() << "in MSG_TYPE_APP_DATA hf接收数据帧 " << byteArrData.toHex(' ');
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>HF接收 数据帧: </b><br>" + byteArrData.toHex(' '));
        m_OpenDialog2->m_serialPort->writeData(m_slipTool.encode(hf_msgFormat(data_hf2icmu_ack())));
    } else if (msgType == MsgTypeMap[MSG_TYPE_ACK]) {
        qDebug() << "in MSG_TYPE_ACK hf接收ACK " + byteArrData.toHex(' ');
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>HF接收 ACK: </b><br>" + byteArrData.toHex(' '));
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:blue'>HF消息发送成功 </b>");
        hfReceiveAckFlag = true;
    } else if (msgType == MsgTypeMap[MSG_TYPE_SILENT]) {
        qDebug() << "in MSG_TYPE_SILENT hf接收静默 " << byteArrData.toHex(' ');
        QByteArray silentData = byteArrData.mid(3, 1);
        hfIsSilent = silentData[0];

        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:green'>HF接收 静默:  </b><br>" + byteArrData.toHex(' '));
        m_OpenDialog2->m_serialPort->writeData(m_slipTool.encode(hf_msgFormat(data_hf2icmu_ack())));

        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:blue'>HF发送 静默状态:  </b><br>" + byteArrData.toHex(' '));
        hfResend(hf_msgFormat(data_icmu2hf_silent(silentData[0])));
    } else if (msgType == MsgTypeMap[MSG_TYPE_LAST_MSG]) {
        qDebug() << "in MSG_TYPE_LAST_MSG hf接收历史链路数据内容 " << byteArrData.toHex(' ');
        // todo hf接受历史链路数据内容
    } else {
        qCritical() << "Error： 本消息不属于任何消息类型 in void MainWindow::hfReceive" << endl;
        ui->textHfLog->append(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") + " <b style='color:red'>HF接收 不属于任何消息类型: </b><br>" + byteArrData.toHex(' '));
    }
}

// 长度与crc校验， byteArrData 没有前后的0xc0
void MainWindow::msgCheck(QByteArray byteArrData)
{
    auto byteArrData_len = byteArrData.left(2);
    auto byteArrData_crc = byteArrData.right(2);
    auto byteArrData_dataAndControl = byteArrData.mid(2, byteArrData.length() - 4);
    int dataLength = byteArrData_len[0] * qPow(2, 8) + byteArrData_len[1];

    if (byteArrData_dataAndControl.size() != dataLength + 1)
        throw QString("in hfReceive  长度校验不正确");
    QByteArray byteArrCRC;
    quint16 dataCRC = ACrc16(reinterpret_cast<const uchar*>(byteArrData_dataAndControl.data()), dataLength + 1); // 算CRC的时候 是 控制+数据
    byteArrCRC
        .append(((unsigned char*)&dataCRC)[1])
        .append(((unsigned char*)&dataCRC)[0]);
    if (byteArrData_crc != byteArrCRC) // todo crc
        throw QString("in hfReceive  CRC校验不正确");
}

// icmu发送 数据帧
void MainWindow::on_btnIcmuDataSend_clicked()
{
    icmuResend(icmu_msgFormat(data_icmu2hf_data(ui->textIcmuData->toPlainText().toStdString())));
    m_logHelper.saveLogFile(ui->textIcmuData->toPlainText(), "_test.dat", PATH_SEND_DATA);
}

// hf发送  数据帧
void MainWindow::on_btnHfDataSend_clicked()
{
    hfResend(hf_msgFormat(data_icmu2hf_data(ui->textHfData->toPlainText().toStdString())));
}

// icmu载入文件信息
void MainWindow::on_btnIcmuDataLoad_clicked()
{
    ui->textIcmuData->setPlainText(m_logHelper.openTxtFile());
}

// hf载入文件信息
void MainWindow::on_btnHfDataLoad_clicked()
{
    ui->textHfData->setPlainText(m_logHelper.openTxtFile());
}

// hf发送心跳，默认优先级 3
QByteArray MainWindow::hf_geneHeartbeat()
{
    QByteArray byteArrRes = hf_msgFormat(data_hf2icmu_state());
    qDebug() << "hf心跳： " << byteArrRes.toHex(' ') << endl;
    return byteArrRes;
}

// icmu向hf发送 静默指令
void MainWindow::on_btnIcmuSilent_clicked()
{
    icmuResend(icmu_msgFormat(data_icmu2hf_silent(HF_SILENT)));
}

// icmu向hf发送 非静默指令
void MainWindow::on_btnIcmuNotSilent_clicked()
{
    icmuResend(icmu_msgFormat(data_icmu2hf_silent(HF_NOT_SILENT)));
}

// hf接收rtu  静默指令
void MainWindow::on_btnHfSilent_clicked()
{
    hfIsSilent = HF_SILENT;
    qDebug() << "hf接收rtu静默指令 hfIsSilent: " << hfIsSilent.getValue() << endl;
    hfReceive(m_slipTool.encode(icmu_msgFormat(data_icmu2hf_silent(HF_SILENT)))); // 先用icmu的模拟一下
}

// hf接收rtu 非静默指令
void MainWindow::on_btnHfNoSilent_clicked()
{
    hfIsSilent = HF_NOT_SILENT;
    qDebug() << "hf接收rtu非静默指令 hfIsSilent: " << hfIsSilent.getValue() << endl;
    hfReceive(m_slipTool.encode(icmu_msgFormat(data_icmu2hf_silent(HF_NOT_SILENT)))); // 先用icmu的模拟一下
}

// 发送 需获取的最近n条信息
void MainWindow::on_btnIcmuSendLastMsg_clicked()
{
    icmuResend(icmu_msgFormat(data_icmu2hf_lastMsg(static_cast<uchar>(ui->spin_last_msg->value()))));
    //    QByteArray a;
    //    a.append(0xc0);
    //    a.append((uchar)0x00); // 长度 2字节
    //    a.append(0x13);
    //    a.append(0x17); // 控制

    //    a.append(0x02);        // 循环体数量
    //    a.append(0x01);        // 序号
    //    a.append((uchar)0x00); // 方向
    //    a.append(0x64);        // 时间戳
    //    a.append(0x68);
    //    a.append(0x3a);
    //    a.append(0x94);
    //    a.append(0x02); // 该条数据帧长度N≤225
    //    a.append(0x08); // 数据2字节
    //    a.append(0x31);

    //    a.append(0x02);        // 序号
    //    a.append((uchar)0x01); // 方向
    //    a.append(0x64);        // 时间戳
    //    a.append(0x68);
    //    a.append(0x4a);
    //    a.append(0x94);
    //    a.append(0x02); // 该条数据帧长度N≤225
    //    a.append(0x09); // 数据 2字节
    //    a.append(0x32);

    //    a.append(0x72); // crc
    //    a.append(0x28);
    //    a.append(0xc0);
    //    icmuReceive(a);
}

// ICMU/HF-1 下传数据帧
// return: 控制+数据
QByteArray MainWindow::data_icmu2hf_data(string msg)
{
    QByteArray byteArrRes;
    QByteArray icmuDataArr = QByteArray::fromStdString(msg); // encodeURI
    foreach (const auto& item, icmuDataArr) byteArrRes.append(item);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_APP_DATA]);
    return byteArrRes;
}

// ICMU/HF-2 ACK帧
// 1字节 ACK	,0-ACK,1-NAK。发送方收到NAK后最多重传2次
QByteArray MainWindow::data_icmu2hf_ack()
{
    QByteArray byteArrRes(1, 0x00);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_ACK]);
    return byteArrRes;
}

// ICMU/HF-3 无线电静默控制
// 1字节 控制命令	0-非静默,1-静默
QByteArray MainWindow::data_icmu2hf_silent(uchar silent)
{
    QByteArray byteArrRes(1, silent);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_SILENT]);
    return byteArrRes;
}

// icmu/HF-4 历史链路数据内容
// 1字节	需要获取的n条信息	N小于≤31
QByteArray MainWindow::data_icmu2hf_lastMsg(uchar lastMsgNum)
{
    QByteArray byteArrRes(1, lastMsgNum);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_LAST_MSG]);
    return byteArrRes;
}

// HF/ICMU-1 上传数据帧
QByteArray MainWindow::data_hf2icmu_data(string msg)
{
    QByteArray byteArrRes;
    QByteArray hfDataArr = QByteArray::fromStdString(msg); // encodeURI
    foreach (const auto& item, hfDataArr) byteArrRes.append(item);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_APP_DATA]);
    return byteArrRes;
}

// HF/ICMU-2 ACK帧
// 1字节 ACK	0-ACK,1-NAK。接收方收到应用数据帧后回复ACK帧；发送方收到NAK后最多重传2次
QByteArray MainWindow::data_hf2icmu_ack()
{
    QByteArray byteArrRes(1, 0x00);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_ACK]);
    return byteArrRes;
}

// HF/ICMU-3 链路状态帧
QByteArray MainWindow::data_hf2icmu_state()
{
    QByteArray byteArrRes;

    // 1字节	信道链路类型	0-空军短波,1-全军短波;
    bool linkType = ui->comboLinkType->currentText().contains("空军短波");
    byteArrRes.append(linkType ? uchar(0x00) : uchar(0x01));

    // 1字节 信道建链/入网状态	0-未入网/未建链,1-已入网/已建链
    bool linkStatus = ui->comboLinkStatus->currentText().contains("未入网/未建链");
    byteArrRes.append(linkStatus ? uchar(0x00) : uchar(0x01));

    // 1字节	成员入网状态	0-成员入网成功，1-成员入网未知，
    bool netStatus = ui->comboNetStatus->currentText().contains("成员入网成功");
    byteArrRes.append(netStatus ? uchar(0x00) : uchar(0x01));

    // 1字节	话音优先	0-无效,1-有效 （有效时，需停止数据链信息的发送）
    bool voiceFirst = ui->comboVoiceFirst->currentText().contains("无效");
    byteArrRes.append(voiceFirst ? uchar(0x00) : uchar(0x01));

    // 1字节	短波数据链速率, 1:600bps,2:880bps,3:1600bps,4:2320bps,5:3040bps
    //                   0:未知       （仅在空军短波链路下有效，全军短波下填0）
    auto datalinkRateText = ui->comboDatalinkRate->currentText();
    byteArrRes.append(DatalinkRateMap.value(datalinkRateText));

    // 电台故障状态	0-正常，1-故障
    bool faultStatus = ui->comboFaultStatus->currentText().contains("正常");
    byteArrRes.append(faultStatus ? uchar(0x00) : uchar(0x01));

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_LINK_STATUS]);

    return byteArrRes;
}

// HF/ICMU-4 无线电静默状态
// 1字节 控制命令	0-非静默,1-静默
QByteArray MainWindow::data_hf2icmu_silent(uchar silent)
{
    QByteArray byteArrRes(1, silent);

    byteArrRes.prepend(MsgTypeMap[MSG_TYPE_SILENT]);
    return byteArrRes;
}

// 短波数据链速率 （仅在空军短波链路下有效，全军短波下填0）
void MainWindow::on_comboLinkType_currentTextChanged(const QString& arg1)
{
    Q_UNUSED(arg1);
    bool linkTypeIsAirForce = ui->comboLinkType->currentText().contains("空军短波");
    if (!linkTypeIsAirForce) {
        ui->comboDatalinkRate->setCurrentIndex(0);
    }
    ui->comboDatalinkRate->setEnabled(linkTypeIsAirForce);
}

// 添加消息头尾
QByteArray MainWindow::msgFormat(QByteArray msgDataWithControl, uchar msgPrio = MsgPrioMap[MSG_PRIORITY_LOW])
{
    QByteArray byteArrPrefix(1, 0xC0);
    QByteArray byteArrDataLength;
    QByteArray byteArrDataWithControl = msgDataWithControl;
    QByteArray byteArrCRC;
    QByteArray byteArrSuffix(1, 0xC0);

    byteArrDataWithControl[0] = byteArrDataWithControl[0] | msgPrio;

    int dataLength = byteArrDataWithControl.size() - 1; // 表示SLIP转义前数据字段的长度
    byteArrDataLength
        .append(((unsigned char*)&dataLength)[1])
        .append(((unsigned char*)&dataLength)[0]);

    quint16 dataCRC = ACrc16(reinterpret_cast<const uchar*>(byteArrDataWithControl.data()), dataLength + 1); // 算CRC的时候 是 控制+数据
    byteArrCRC
        .append(((unsigned char*)&dataCRC)[1])
        .append(((unsigned char*)&dataCRC)[0]);

    return byteArrPrefix + byteArrDataLength + byteArrDataWithControl + byteArrCRC + byteArrSuffix;
}

QByteArray MainWindow::icmu_msgFormat(QByteArray msgDataWithControl)
{
    auto msgPrioText = ui->comboIcmuMsgPriority->currentText();
    uchar msgPrio = MsgPrioMap.value(msgPrioText);
    return msgFormat(msgDataWithControl, msgPrio);
}

QByteArray MainWindow::hf_msgFormat(QByteArray msgDataWithControl)
{
    auto msgPrioText = ui->comboHfMsgPriority->currentText();
    uchar msgPrio = MsgPrioMap.value(msgPrioText);
    return msgFormat(msgDataWithControl, msgPrio);
}

void MainWindow::on_btnIcmuLogExport_clicked()
{
    m_logHelper.saveLogFile(ui->textIcmuLog->toPlainText(), "icmu.log", PATH_LOG);
}

void MainWindow::on_btnHfLogExport_clicked()
{
    m_logHelper.saveLogFile(ui->textHfLog->toPlainText(), "hf.log", PATH_LOG);
}

// 数据比对
void MainWindow::on_btnDataCompare_clicked()
{
    m_CompareWindow->exec();
}

// 是否显示心跳
void MainWindow::on_checkBoxShowHeartbeat_stateChanged(int arg1)
{
    showHeartbeat = arg1 == Qt::Checked;
}
