#ifndef OPENDIALOG_H
#define OPENDIALOG_H

#include <QDebug>
#include <QDialog>
#include <QMessageBox>
#include <QSerialPortInfo>

#include "utils/serial_port.h"

namespace Ui {
    class OpenDialog;
}

class OpenDialog : public QDialog {
    Q_OBJECT

public:
    explicit OpenDialog(QWidget* parent = nullptr);
    ~OpenDialog();

public:
    void closePort();

    SerialPort* m_serialPort;

    void addPorts();
private slots:
    void on_btn_Confirm_clicked();

    void on_btn_Cancle_clicked();

private:
    Ui::OpenDialog* ui;
};

#endif // OPENDIALOG_H
