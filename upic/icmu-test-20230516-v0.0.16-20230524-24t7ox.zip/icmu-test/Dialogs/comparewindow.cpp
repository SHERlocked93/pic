﻿#include "comparewindow.h"

#include "ui_comparewindow.h"

CompareWindow::CompareWindow(QWidget* parent)
    : QDialog(parent), ui(new Ui::CompareWindow)
{
    ui->setupUi(this);
    m_sendPath = QCoreApplication::applicationDirPath() + "/AllMessage/SendData"; // 原用 QDir::currentPath()
    m_recvPath = QCoreApplication::applicationDirPath() + "/AllMessage/RecvData";
    this->setWindowTitle("数据比对");
}

CompareWindow::~CompareWindow()
{
    delete ui;
}

int CompareWindow::InputData(bool bSend)
{
    if (bSend) {
        int rowcount = ui->tableWidgetSend->rowCount();
        for (int i = 0; i < rowcount; i++)
            ui->tableWidgetSend->removeRow(0);
    } else {
        int rowcount = ui->tableWidgetRecv->rowCount();
        for (int i = 0; i < rowcount; i++)
            ui->tableWidgetRecv->removeRow(0);
    }
    QString tmpFileName;
    QString tmpCS;
    QString tmpPath = bSend ? m_sendPath : m_recvPath;
    QStringList tmpList;
    QDir dir(tmpPath);
    QFile tmpFile;
    QStringList namefilter;
    namefilter << "*.dat";
    tmpList = dir.entryList(namefilter, QDir::Files | QDir::Readable, QDir::Name);

    for (int i = 0; i < tmpList.count(); i++) {
        tmpFileName = tmpList[i];
        tmpFile.setFileName(tmpPath + QString("/") + tmpFileName);
        if (tmpFile.open(QFile::ReadOnly | QIODevice::Text)) {
            if (bSend) {
                int rowcount = ui->tableWidgetSend->rowCount();
                ui->tableWidgetSend->insertRow(rowcount);
            } else {
                int rowcount = ui->tableWidgetRecv->rowCount();
                ui->tableWidgetRecv->insertRow(rowcount);
            }
            int tmpCol = 1;
            QDateTime tmpTime;
            GetTimeFromPath(tmpTime, tmpCS, tmpFileName);
            if (bSend) {
                ui->tableWidgetSend->setItem(i, 0, new QTableWidgetItem(QString("%1").arg(i + 1)));
                ui->tableWidgetSend->setItem(i, 1, new QTableWidgetItem(QString("%1").arg(tmpCS)));
                ui->tableWidgetSend->setItem(i, 2, new QTableWidgetItem(QString("%1").arg(tmpFile.size())));
                ui->tableWidgetSend->setItem(i, 3, new QTableWidgetItem());
                ui->tableWidgetSend->setItem(i, 4, new QTableWidgetItem());
                ui->tableWidgetSend->setItem(i, 5, new QTableWidgetItem());
                ui->tableWidgetSend->setItem(i, 6, new QTableWidgetItem(tmpPath + QString("/") + tmpFileName));
            } else {
                ui->tableWidgetRecv->setItem(i, 0, new QTableWidgetItem(QString("%1").arg(i + 1)));
                ui->tableWidgetRecv->setItem(i, 1, new QTableWidgetItem(QString("%1").arg(tmpCS)));
                ui->tableWidgetRecv->setItem(i, 2, new QTableWidgetItem(QString("%1").arg(tmpFile.size())));
                ui->tableWidgetRecv->setItem(i, 3, new QTableWidgetItem(tmpPath + QString("/") + tmpFileName));
            }
            tmpFile.close();
        }
    }
    return 1;
}

void CompareWindow::GetTimeFromPath(QDateTime& time, QString& name, QString path)
{
    //    int stop = path.indexOf(".");
    QStringList m_strlist = path.split("_");
    name = m_strlist[7];
    name = name.replace(".dat", "");

    time.setDate(QDate(QString("%1").arg(m_strlist[0]).toInt(),
                       QString("%1").arg(m_strlist[1]).toInt(),
                       QString("%1").arg(m_strlist[2]).toInt()));
    time.setTime(QTime(QString("%1").arg(m_strlist[3]).toInt(),
                       QString("%1").arg(m_strlist[4]).toInt(),
                       QString("%1").arg(m_strlist[5]).toInt(),
                       QString("%1").arg(m_strlist[6]).toInt()));
}

void CompareWindow::on_btnRefreshData_clicked()
{
    InputData(true);
    InputData(false);
}

void CompareWindow::on_btnStartCompare_clicked()
{
    int allCount = ui->tableWidgetSend->rowCount();
    if (allCount < 1)
        return;
    int recvCount = ui->tableWidgetRecv->rowCount();
    int factCount = 0, succCount = 0;
    qint64 allTime = 0;
    float allWuma = 0;
    int wumaCount = 0;
    QString tmpCS;
    QString filePathS, filePathR, oldPath;

    QFile tmpFile;
    ST_TEST_INFO sendInfo, recvInfo;
    QDateTime newTime;
    for (int m = 0; m < allCount + 1; m++) {
        if (m < allCount) {
            filePathS = ui->tableWidgetSend->item(m, 6)->text();
            if (oldPath.length() == 0) {
                tmpFile.setFileName(filePathS);
                if (tmpFile.open(QFile::ReadOnly)) {
                    QByteArray buf = tmpFile.readAll();
                    sendInfo.dataLen = buf.length();
                    memcpy(sendInfo.data, buf.data(), sendInfo.dataLen);
                } else
                    QMessageBox::information(this, "提示", QString("文件%1打开失败!").arg(filePathS));
                tmpFile.close();
                oldPath = filePathS;
                QFileInfo m_info(filePathS);
                GetTimeFromPath(sendInfo.sendTime, tmpCS, m_info.fileName());
                continue;
            }
            QFileInfo m_info(filePathS);
            GetTimeFromPath(newTime, tmpCS, m_info.fileName());
        }
        factCount++;
        int n = 0;
        for (; n < recvCount; n++) {
            filePathR = ui->tableWidgetRecv->item(n, 3)->text();
            QFileInfo m_info(filePathR);
            GetTimeFromPath(recvInfo.recvTime, tmpCS, m_info.fileName());
            bool bIn = false;
            if (m < allCount && GetTimeSpan(sendInfo.sendTime, recvInfo.recvTime) > 0 && GetTimeSpan(recvInfo.recvTime, newTime) > 0)
                bIn = true;
            else if (m > allCount - 1 && GetTimeSpan(sendInfo.sendTime, recvInfo.recvTime) > 0)
                bIn = true;
            if (bIn) // 比较时间在区间内 )
            {
                tmpFile.setFileName(filePathR);
                if (tmpFile.open(QFile::ReadOnly)) {
                    QByteArray buf = tmpFile.readAll();
                    recvInfo.dataLen = buf.length();
                    memcpy(recvInfo.data, buf.data(), recvInfo.dataLen);
                    tmpCS = QString("%1").arg(GetTimeSpan(sendInfo.sendTime, recvInfo.recvTime));
                    ui->tableWidgetSend->item(m - 1, 4)->setText(tmpCS);
                } else
                    QMessageBox::information(this, "提示", QString("文件%1打开失败!").arg(filePathS));
                tmpFile.close();
                break;
            }
        }
        if (n == recvCount) {
            ui->tableWidgetSend->item(m - 1, 3)->setText("X");
            ui->tableWidgetSend->item(m - 1, 5)->setText("区间内未找到本条数据!");
        } else {
            QString errorString;
            qint64 timeSpan;
            float wuma;
            if (CompareData(&sendInfo, &recvInfo, errorString, timeSpan, wuma)) {
                succCount++;
                allTime += timeSpan;
                ui->tableWidgetSend->item(m - 1, 3)->setText("V");
                ui->tableWidgetSend->item(m - 1, 5)->setText(errorString);
            } else {
                ui->tableWidgetSend->item(m - 1, 3)->setText("X");
                ui->tableWidgetSend->item(m - 1, 5)->setText(errorString);
            }
            allWuma += wuma;
            wumaCount++;
        }
        // 数据转移到old中
        tmpFile.setFileName(filePathS);
        if (tmpFile.open(QFile::ReadOnly)) {
            QByteArray buf = tmpFile.readAll();
            sendInfo.dataLen = buf.length();
            memcpy(sendInfo.data, buf.data(), sendInfo.dataLen);
        } else
            QMessageBox::information(this, "提示", QString("文件%1打开失败!").arg(filePathS));
        tmpFile.close();
        oldPath = filePathS;
        QFileInfo m_info(filePathS);
        GetTimeFromPath(sendInfo.sendTime, tmpCS, m_info.fileName());
    }
    QString result;
    if (succCount == 0)
        result = QString("对比结果:\r\n总发送条数:%1,跳过:%2,成功:0,成功率:0\r\n平均误码率:%3(丢包不计算) 平均时延:--ms(失败不计算时延)")
                     .arg(allCount)
                     .arg(allCount - factCount)
                     .arg(double(1.0 - allWuma / double(wumaCount)) * 100.0, 2, 'f', 2, QChar('0'));
    else
        result = QString("对比结果:\r\n总发送条数:%1,跳过:%2成功:%3,成功率:%4\r\n平均误码率:%5%(丢包不计算) 平均时延:%6ms(失败不计算时延)")
                     .arg(allCount)
                     .arg(allCount - factCount)
                     .arg(succCount)
                     .arg(factCount ? succCount * 100 / factCount : 0)
                     .arg(double(1.0 - allWuma / float(wumaCount)) * 100.0, 2, 'f', 2, QChar('0'))
                     .arg(allTime / succCount);
    QMessageBox::information(this, "对比结果", result);
    result.remove('\n');
    result.remove('\r');
    ui->labelResult->setText(result);
}

qint64 CompareWindow::GetTimeSpan(QDateTime left, QDateTime right)
{
    if (left.date().year() < 1970 ||
        left.date().month() > 12 ||
        left.date().day() > 31 ||
        left.time().hour() > 23 ||
        left.time().minute() > 59 ||
        left.time().msec() > 999 ||
        right.date().year() < 1970 ||
        right.date().month() > 12 ||
        right.date().day() > 31 ||
        right.time().hour() > 23 ||
        right.time().minute() > 59 ||
        right.time().msec() > 999) {
        QMessageBox::information(this, "提示", QString("非法时间!"));
        return 0;
    }
    QDateTime tmLeft(QDate(left.date().year(), left.date().month(), left.date().day()), QTime(left.time().hour(), left.time().minute(), left.time().second(), left.time().msec()));
    QDateTime tmRight(QDate(right.date().year(), right.date().month(), right.date().day()), QTime(right.time().hour(), right.time().minute(), right.time().second(), right.time().msec()));
    qint64 ret = tmLeft.msecsTo(tmRight);
    return ret; // 此处返回毫秒，可用根据自己的格式需要进行转换，如时分秒
}

bool CompareWindow::CompareData(ST_TEST_INFO* sendInfo, ST_TEST_INFO* recvInfo, QString& errorString, qint64& timeSpan, float& wuma)
{
    ST_TEST_HEAD* sendHead = (ST_TEST_HEAD*)sendInfo->data;
    ST_TEST_HEAD* recvHead = (ST_TEST_HEAD*)recvInfo->data;
    // if(recvInfo->dataLen == 0 &&  h)
    //{
    //	errorString.Format("接收文件读取失败,可能未接收到该此测试数据!");
    //	return FALSE;
    // }
    /*
    if(recvInfo->dataLen!=sendInfo->dataLen)
    {
        errorString.Format("数据长度校验失败,发长度:%d,收长度:%d",sendInfo->dataLen,recvInfo->dataLen);
        if(  recvHead->GetType() != TYPE_TEST_PTT && recvHead->GetType() != TYPE_TEST_VMSG)//非实时话
            return FALSE;
    }*/
    // int minLen = sendInfo->dataLen>recvInfo->dataLen?recvInfo->dataLen:sendInfo->dataLen;
    /*

    if( sendHead->GetType() == TYPE_TEST_LQA )//探测对比单独处理
    {
        //return TRUE;
        if( timeSpan > here->m_dlgDataTest.m_lqaMaxTimeSpan )//时延大于配置值
        {
            errorString.Format("探测处理时延 %ds 大于 %ds (配置值)，探测失败!",timeSpan,here->m_dlgDataTest.m_lqaMaxTimeSpan);
            return FALSE;
        }
        else
        {
            errorString.Format("探测处理时延 %ds 小于 %ds (配置值)，探测成功!",timeSpan,here->m_dlgDataTest.m_lqaMaxTimeSpan);
            return TRUE;
        }
    }*/
    timeSpan = GetTimeSpan(sendInfo->sendTime, recvInfo->recvTime);
    float ret = CheckData(sendInfo->data, sendInfo->dataLen, recvInfo->data, recvInfo->dataLen);
    wuma = ret;
    if (ret != 1.0) {
        errorString = QString("数据内容校验失败,误码率%1").arg(double(1.0 - ret) * 100.0, 2, 'f', 2, QChar('0'));
        return 0; // false
    } else {
        // errorString.Format("数据内容校验失败,误码率%2.2f%%",ret);
        return 1; // true
    }
}
#define FIND_HEAD_LEN 4
float CompareWindow::CheckData(unsigned char* src, int lenSrc, unsigned char* dest, int lenDest)
{
    if (lenSrc == 0)
        return 1.0;
    if (lenSrc < lenDest) // 收多了，直接截断
        lenDest = lenSrc;
    int rightCount = 0;
    if (lenDest < FIND_HEAD_LEN) // 太短不找头部了，直接对比
    {
        for (int m = 0; m < lenDest; m++) {
            if (src[m] == dest[m])
                rightCount++;
        }
    } else {
        int start = FindHead(src, lenSrc, dest, lenDest);
        for (int m = 0; m < ((lenSrc - start) > lenDest ? lenDest : (lenSrc - start)); m++) {
            if (src[start + m] == dest[m])
                rightCount++;
        }
    }
    return float(rightCount) / float(lenSrc);
}
int CompareWindow::FindHead(unsigned char* src, int lenSrc, unsigned char* dest, int lenDest)
{
    int start = 0;
refind:
    int m = 0;
    for (; m < FIND_HEAD_LEN; m++) {
        if (src[start + m] != dest[m])
            break;
    }
    if (m == FIND_HEAD_LEN) // 找到了
        return start;
    else {
        start++;
        if (start == lenSrc - FIND_HEAD_LEN)
            return 0; // 没找到,直接从头比较
        goto refind;
    }
}

void CompareWindow::on_btnClearData_clicked()
{
    QDir d(m_recvPath);
    d.setFilter(QDir::Files);
    int i, j = d.count() - 1;
    for (i = 0; i <= j; i++) {
        d.remove(d[i]);
    }
    d.setPath(m_sendPath);
    d.setFilter(QDir::Files);
    j = d.count() - 1;
    for (i = 0; i <= j; i++) {
        d.remove(d[i]);
    }
    ui->btnRefreshData->click();
}

void CompareWindow::on_btnSendData_clicked()
{
    QDesktopServices::openUrl(QUrl(m_sendPath));
    qDebug() << "文档路径: " << m_sendPath << endl;
}

void CompareWindow::on_btnRecvData_clicked()
{
    QDesktopServices::openUrl(QUrl(m_recvPath));
}
