﻿#ifndef COMPAREWINDOW_H
#define COMPAREWINDOW_H

#include <QDateTime>
#include <QDebug>
#include <QDesktopServices>
#include <QDialog>
#include <QDir>
#include <QMessageBox>
#include <QUrl>

namespace Ui {
class CompareWindow;
}

#define MAX_TEST_DATA 1024 * 128 // 定义buffer最大发送字节数

struct ST_TEST_INFO {
    int type;
    int count;
    int countFact;
    int countSucc;
    int rate;
    int jz;
    bool bTesting;
    bool isTest21;
    int dataLen;
    int testSpanMs;
    unsigned int testAllTime;
    bool needPreTime;
    QString testFilePath;
    QDateTime sendTime;
    QDateTime recvTime;
    unsigned char data[MAX_TEST_DATA];
    void ClearValue()
    {
        type = 0;
        count = 0;
        countFact = 0;
        countSucc = 0;
        rate = 0;
        jz = 0;
        bTesting = false;
        needPreTime = false;
        dataLen = 0;
        testSpanMs = 0;
        testAllTime = 0;
        testFilePath = QString("");
        memset(data, 0, MAX_TEST_DATA);
    }
    ST_TEST_INFO()
    {
        ClearValue();
    }
    ~ST_TEST_INFO() {}
};

struct ST_TEST_HEAD {
    // unsigned int			sn		:16		;//范围0-65535
    // unsigned int			type	:8			;
    // unsigned int			key		:8			;//188为测试数据
    // unsigned int			rev		:15		;//保留,实时话时，此段数据不可用
    // unsigned int			rev1	:1			;//保留,太小也没啥用
    unsigned char sn1[4]; // 范围0-65535
    unsigned char rev1[2];
    unsigned char sn2; // 范围0-65535
    unsigned char type[2];
    unsigned char key; //'T'为测试数据
    unsigned char rev2[2];
    int GetSn(void)
    {
        char tmpData[10] = {0};
        memcpy(tmpData, sn1, 4);
        tmpData[4] = sn2;
        return atoi(tmpData);
    }
    void SetSn(quint16 value)
    {
        char tmpData[10] = {0};
        sprintf(tmpData, "%05d", value);
        memcpy(sn1, tmpData, 4);
        sn2 = tmpData[4];
    }
    void SetType(int value)
    {
        char tmpData[10] = {0};
        sprintf(tmpData, "%02d", value);
        memcpy(type, tmpData, 2);
    }
    int GetType(void)
    {
        char tmpData[10] = {0};
        memcpy(tmpData, type, 2);
        return atoi(tmpData);
    }
};

class CompareWindow : public QDialog {
    Q_OBJECT

public:
    explicit CompareWindow(QWidget* parent = nullptr);
    ~CompareWindow();
    QString m_recvPath, m_sendPath;
    int InputData(bool bSend);
    void GetTimeFromPath(QDateTime& time, QString& name, QString path);
    qint64 GetTimeSpan(QDateTime left, QDateTime right);
    bool CompareData(ST_TEST_INFO* sendInfo, ST_TEST_INFO* recvInfo, QString& errorString, qint64& timeSpan, float& wuma);
    float CheckData(unsigned char* src, int lenSrc, unsigned char* dest, int lenDest);
    int FindHead(unsigned char* src, int lenSrc, unsigned char* dest, int lenDest);

private:
    Ui::CompareWindow* ui;
private slots:
    void on_btnRefreshData_clicked();
    void on_btnStartCompare_clicked();
    void on_btnClearData_clicked();
    void on_btnSendData_clicked();
    void on_btnRecvData_clicked();
};

#endif // COMPAREWINDOW_H
