#include "opendialog.h"

#include "ui_opendialog.h"

OpenDialog::OpenDialog(QWidget* parent)
    : QDialog(parent), ui(new Ui::OpenDialog)
{
    ui->setupUi(this);
    m_serialPort = new SerialPort(this);
    addPorts();
}

OpenDialog::~OpenDialog()
{
    delete ui;
    delete m_serialPort;
}

void OpenDialog::closePort()
{
    m_serialPort->closePort();
}

void OpenDialog::on_btn_Confirm_clicked()
{
    QString portName = ui->comboBoxPort->currentText();
    qDebug() << "打开串口： " << portName << endl;

    QSerialPort::DataBits dataBits = static_cast<QSerialPort::DataBits>(ui->comboBoxData->currentText().toInt());

    QSerialPort::BaudRate baudRate = static_cast<QSerialPort::BaudRate>(ui->comboBoxBaudRate->currentText().toInt());

    QString parityStr = ui->comboBoxCRC->currentText();
    QSerialPort::Parity parity;

    if (parityStr == "even") {
        parity = QSerialPort::Parity::EvenParity;
    } else if (parityStr == "odd") {
        parity = QSerialPort::Parity::OddParity;
    } else {
        parity = QSerialPort::Parity::NoParity;
    }

    QString stopBitsStr = ui->comboBoxStop->currentText();
    QSerialPort::StopBits stopBits;

    if (stopBitsStr == "1") {
        stopBits = QSerialPort::StopBits::OneStop;
    } else if (stopBitsStr == "2") {
        stopBits = QSerialPort::StopBits::TwoStop;
    } else {
        stopBits = QSerialPort::StopBits::OneAndHalfStop;
    }

    if (EXIT_SUCCESS == m_serialPort->openPort(portName, baudRate, dataBits, parity, stopBits)) {
        this->close();
    } else
        QMessageBox::critical(this, "Error", "串口 " + portName + " 打开失败");
}

void OpenDialog::on_btn_Cancle_clicked()
{
    this->close();
}

void OpenDialog::addPorts()
{
    QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    foreach (const QSerialPortInfo& portInfo, ports) {
        ui->comboBoxPort->addItem(portInfo.portName());
    }
}
